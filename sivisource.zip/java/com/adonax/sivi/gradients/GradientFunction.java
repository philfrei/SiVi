package com.adonax.sivi.gradients;

public interface GradientFunction
{
	public float get(int x, int y);
}
