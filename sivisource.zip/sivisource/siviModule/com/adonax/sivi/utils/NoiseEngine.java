package com.adonax.sivi.utils;

public interface NoiseEngine {

	double noise(double xin, double yin);
	double noise(double xin, double yin, double zin);	 
	
}
